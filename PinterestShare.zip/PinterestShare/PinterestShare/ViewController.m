//
//  ViewController.m
//  PinterestShare
//
//  Created by Jyoti Sahu on 5/21/16.
//  Copyright © 2016 PinterestShare. All rights reserved.
//

#import "ViewController.h"
#import "PDKClient.h"
#import "PDKResponseObject.h"
#import "PDKUser.h"

@interface ViewController ()
@property (nonatomic, strong) PDKUser *user;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [PDKClient configureSharedInstanceWithAppId:@"4830118125137577157"];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)Login:(id)sender {
    
    __weak ViewController *weakSelf = self;

    [[PDKClient sharedInstance] authenticateWithPermissions:@[PDKClientReadPublicPermissions,
                                                              PDKClientWritePublicPermissions,
                                                              PDKClientReadPrivatePermissions,
                                                              PDKClientWritePrivatePermissions,
                                                              PDKClientReadRelationshipsPermissions,
                                                              PDKClientWriteRelationshipsPermissions]
                                                withSuccess:^(PDKResponseObject *responseObject)
    {
        weakSelf.user = [responseObject user];
        NSLog(@"authentication : %@", weakSelf.user);

        
    } andFailure:^(NSError *error) {
        NSLog(@"authentication failed: %@", error);
    }];
}
- (IBAction)ShareORFOllow:(id)sender {
}

@end
