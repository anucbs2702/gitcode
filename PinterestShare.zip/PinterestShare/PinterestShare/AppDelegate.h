//
//  AppDelegate.h
//  PinterestShare
//
//  Created by Jyoti Sahu on 5/21/16.
//  Copyright © 2016 PinterestShare. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

